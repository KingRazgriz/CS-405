// Encryption.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <cassert>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <ctime>

/// <summary>
/// encrypt or decrypt a source string using the provided key
/// Uses XOR cipher pattern: same operation for both encryption and decryption
/// </summary>
/// <param name="source">input string to process</param>
/// <param name="key">key to use in encryption / decryption</param>
/// <returns>transformed string</returns>
std::string encrypt_decrypt(const std::string& source, const std::string& key)
{
    // get lengths now instead of calling the function every time.
    // this would have most likely been inlined by the compiler, but design for perfomance.
    const auto key_length = key.length();
    const auto source_length = source.length();

    // assert that our input data is good
    assert(key_length > 0);
    assert(source_length > 0);

    std::string output = source;

    // loop through the source string char by char
    for (size_t i = 0; i < source_length; ++i)
    {
        // XOR encryption/decryption: 
        // Each character is transformed using XOR with corresponding key character
        // Key is reused cyclically using modulo operator for variable-length keys
        // XOR cipher provides symmetric encryption: (data ^ key) ^ key = data
        output[i] = source[i] ^ key[i % key_length];
    }

    // our output length must equal our source length
    assert(output.length() == source_length);

    // return the transformed string
    return output;
}

/// <summary>
/// Reads entire contents of a text file into a string
/// Implements file I/O error handling and stream buffer reading pattern
/// </summary>
/// <param name="filename">name of file to read</param>
/// <returns>file contents as string</returns>
std::string read_file(const std::string& filename)
{
    // Default fallback content if file cannot be read
    std::string file_text = "John Q. Smith\nThis is my test string";

    // TODO: implement loading the file into a string
    std::ifstream file(filename); // Opens the file for reading.
    std::ostringstream buffer;
    if (file)
    {
        buffer << file.rdbuf(); // Reads the file before buffering.
        file_text = buffer.str(); // Coverts the buffered file to a string.
    }
    else
    {
        // Enhanced error reporting for debugging
        std::cerr << "Warning: Could not open input file '" << filename
            << "'. Using default content." << std::endl;
    }

    return file_text;
}

/// <summary>
/// Extracts student name from the first line of file data
/// Uses string search pattern to locate and extract specific data
/// </summary>
/// <param name="string_data">complete file content</param>
/// <returns>student name from first line</returns>
std::string get_student_name(const std::string& string_data)
{
    std::string student_name;

    // find the first newline
    size_t pos = string_data.find('\n');
    // did we find a newline
    if (pos != std::string::npos)
    { // we did, so copy that substring as the student name
        student_name = string_data.substr(0, pos);
    }
    else
    {
        // Handle case where no newline exists - use entire string
        student_name = string_data;
    }

    return student_name;
}

/// <summary>
/// Saves encrypted/decrypted data to file with metadata header
/// Implements file output pattern with structured formatting
/// </summary>
/// <param name="filename">output file name</param>
/// <param name="student_name">student identifier</param>
/// <param name="key">encryption key used</param>
/// <param name="data">content to save</param>
void save_data_file(const std::string& filename, const std::string& student_name, const std::string& key, const std::string& data)
{
    //  TODO: implement file saving
    //  file format
    //  Line 1: student name
    //  Line 2: timestamp (yyyy-mm-dd)
    //  Line 3: key used
    //  Line 4+: data
    std::ofstream file(filename); // Opens the file for writing.
    if (file)
    {
        // Get current date using time handling pattern
        std::time_t now = std::time(nullptr);
        struct tm local;
        localtime_s(&local, &now); // Replaces the localtime_s for safety.

        // Format date with ISO 8601 standard (YYYY-MM-DD)
        // Use stream formatting for zero-padded months and days
        file << student_name << "\n"; // Writes out student name in the file.
        file << (1900 + local.tm_year) << "-"
            << std::setw(2) << std::setfill('0') << (1 + local.tm_mon) << "-"
            << std::setw(2) << std::setfill('0') << local.tm_mday << "\n"; // Writes out the current date.
        file << key << "\n";
        file << data; // Write data without extra newline to preserve exact content
    }
    else
    {
        std::cerr << "Error: Could not create output file '" << filename << "'" << std::endl;
    }
}

/// <summary>
/// Main program demonstrating encryption/decryption workflow
/// Implements Template Method pattern for cryptographic operations
/// </summary>
int main()
{
    std::cout << "Encryption Decryption Test!" << std::endl;

    // input file format
    // Line 1: <students name>
    // Line 2: <Lorem Ipsum Generator website used> https://pirateipsum.me/ (could be https://www.lipsum.com/ or one of https://www.shopify.com/partners/blog/79940998-15-funny-lorem-ipsum-generators-to-shake-up-your-design-mockups)
    // Lines 3+: <lorem ipsum generated with 3 paragraphs> 
    //  Fire in the hole bowsprit Jack Tar gally holystone sloop grog heave to grapple Sea Legs. Gally hearties case shot crimp spirits pillage galleon chase guns skysail yo-ho-ho. Jury mast coxswain measured fer yer chains man-of-war Privateer yardarm aft handsomely Jolly Roger mutiny.
    //  Hulk coffer doubloon Shiver me timbers long clothes skysail Nelsons folly reef sails Jack Tar Davy Jones' Locker. Splice the main brace ye fathom me bilge water walk the plank bowsprit gun Blimey wench. Parrel Gold Road clap of thunder Shiver me timbers hempen halter yardarm grapple wench bilged on her anchor American Main.
    //  Brigantine coxswain interloper jolly boat heave down cutlass crow's nest wherry dance the hempen jig spirits. Interloper Sea Legs plunder shrouds knave sloop run a shot across the bow Jack Ketch mutiny barkadeer. Heave to gun matey Arr draft jolly boat marooned Cat o'nine tails topsail Blimey.

    // File name constants following naming conventions
    const std::string file_name = "inputdatafile.txt";
    const std::string encrypted_file_name = "encrypteddatafile.txt";
    const std::string decrypted_file_name = "decrypteddatafile.txt";
    const std::string key = "secure_password_123"; // Enhanced key for better security

    // Read source data using file I/O pattern
    const std::string source_string = read_file(file_name);

    // get the student name from the data file using data extraction pattern
    const std::string student_name = get_student_name(source_string);

    // Display operational status
    std::cout << "Processing data for: " << student_name << std::endl;
    std::cout << "Source text length: " << source_string.length() << " characters" << std::endl;

    // encrypt sourceString with key using XOR cipher pattern
    const std::string encrypted_string = encrypt_decrypt(source_string, key);

    // save encrypted_string to file using file output pattern
    save_data_file(encrypted_file_name, student_name, key, encrypted_string);

    // decrypt encryptedString with key using symmetric XOR pattern
    const std::string decrypted_string = encrypt_decrypt(encrypted_string, key);

    // save decrypted_string to file using file output pattern
    save_data_file(decrypted_file_name, student_name, key, decrypted_string);

    // Output results summary
    std::cout << "Read File: " << file_name << " - Encrypted To: " << encrypted_file_name << " - Decrypted To: " << decrypted_file_name << std::endl;

    // Verification of cryptographic operations
    if (source_string == decrypted_string) {
        std::cout << "SUCCESS: Encryption and decryption completed successfully!" << std::endl;
        std::cout << "Original and decrypted texts are identical." << std::endl;
    }
    else {
        std::cout << "ERROR: Decryption failed to restore original text!" << std::endl;
        std::cout << "Original length: " << source_string.length()
            << ", Decrypted length: " << decrypted_string.length() << std::endl;
    }

    // students submit input file, encrypted file, decrypted file, source code file, and key used
    return 0; // Explicit return for program completion
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu