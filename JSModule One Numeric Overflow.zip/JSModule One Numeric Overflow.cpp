#include <iostream>     // std::cout
#include <limits>       // std::numeric_limits
#include <typeinfo>     // typeid

// Helper function to detect addition overflow
template <typename T>
bool will_overflow_add(T a, T b) {
    if (b > 0) {
        return a > std::numeric_limits<T>::max() - b;
    }
    else {
        return a < std::numeric_limits<T>::min() - b;
    }
}

// Helper function to detect subtraction underflow
template <typename T>
bool will_underflow_subtract(T a, T b) {
    if (b > 0) {
        return a < std::numeric_limits<T>::min() + b;
    }
    else {
        return a > std::numeric_limits<T>::max() + b;
    }
}

/// <summary>
/// Template function to abstract away the logic of:
///   start + (increment * steps)
/// </summary>
/// <typeparam name="T">A type that with basic math functions</typeparam>
/// <param name="start">The number to start with</param>
/// <param name="increment">How much to add each step</param>
/// <param name="steps">The number of steps to iterate</param>
/// <param name="result">Output parameter for the result</param>
/// <returns>true if successful, false if overflow occurred</returns>
template <typename T>
bool add_numbers(T const& start, T const& increment, unsigned long int const& steps, T& result)
{
    result = start;

    for (unsigned long int i = 0; i < steps; ++i)
    {
        // Detect overflow before adding
        if (will_overflow_add(result, increment)) {
            return false; // Overflow detected - signal failure
        }
        result += increment;
    }

    return true; // Success
}

/// <summary>
/// Template function to abstract away the logic of:
///   start - (increment * steps)
/// </summary>
/// <typeparam name="T">A type that with basic math functions</typeparam>
/// <param name="start">The number to start with</param>
/// <param name="decrement">How much to subtract each step</param>
/// <param name="steps">The number of steps to iterate</param>
/// <param name="result">Output parameter for the result</param>
/// <returns>true if successful, false if underflow occurred</returns>
template <typename T>
bool subtract_numbers(T const& start, T const& decrement, unsigned long int const& steps, T& result)
{
    result = start;

    for (unsigned long int i = 0; i < steps; ++i)
    {
        // Detect underflow before subtracting
        if (will_underflow_subtract(result, decrement)) {
            return false; // Underflow detected - signal failure
        }
        result -= decrement;
    }

    return true; // Success
}

//  NOTE:
//    You will see the unary ('+') operator used in front of the variables in the test_XXX methods.
//    This forces the output to be a number for cases where cout would assume it is a character. 

template <typename T>
void test_overflow()
{
    // START DO NOT CHANGE
    //  how many times will we iterate
    const unsigned long int steps = 5;
    // how much will we add each step (result should be: start + (increment * steps))
    const T increment = std::numeric_limits<T>::max() / steps;
    // whats our starting point
    const T start = 0;

    std::cout << "Overflow Test of Type = " << typeid(T).name() << std::endl;
    // END DO NOT CHANGE

    std::cout << "\tAdding Numbers Without Overflow (" << +start << ", " << +increment << ", " << steps << ") = ";
    T result;
    bool success = add_numbers<T>(start, increment, steps, result);
    std::cout << +result << " (overflow: " << std::boolalpha << !success << ")" << std::endl;

    std::cout << "\tAdding Numbers With Overflow (" << +start << ", " << +increment << ", " << (steps + 1) << ") = ";
    success = add_numbers<T>(start, increment, steps + 1, result);
    if (!success) {
        std::cout << "OVERFLOW DETECTED! (overflow: true)" << std::endl;
    }
    else {
        std::cout << +result << " (overflow: false)" << std::endl;
    }
}

template <typename T>
void test_underflow()
{
    // START (Do Not Change)
    // How many iterations.
    const unsigned long int steps = 5;
    // Subtract from each step.  (result should be: start - (increment * steps))
    const T decrement = std::numeric_limits<T>::max() / steps;
    // wWhat is the starting point?.
    const T start = std::numeric_limits<T>::max();

    std::cout << "Underflow Test of Type = " << typeid(T).name() << std::endl;
    // END (Do Not Change)

    std::cout << "\tSubtracting Numbers Without Underflow (" << +start << ", " << +decrement << ", " << steps << ") = ";
    T result;
    bool success = subtract_numbers<T>(start, decrement, steps, result);
    std::cout << +result << " (underflow: " << std::boolalpha << !success << ")" << std::endl;

    std::cout << "\tSubtracting Numbers With Underflow (" << +start << ", " << +decrement << ", " << (steps + 1) << ") = ";
    success = subtract_numbers<T>(start, decrement, steps + 1, result);
    if (!success) {
        std::cout << "UNDERFLOW DETECTED! (underflow: true)" << std::endl;
    }
    else {
        std::cout << +result << " (underflow: false)" << std::endl;
    }
}

void do_overflow_tests(const std::string& star_line)
{
    std::cout << std::endl << star_line << std::endl;
    std::cout << "*** Running Overflow Tests ***" << std::endl;
    std::cout << star_line << std::endl;

    // Testing C++ primative times see: https://www.geeksforgeeks.org/c-data-types/
    // Signed integers.
    test_overflow<char>();
    test_overflow<wchar_t>();
    test_overflow<short int>();
    test_overflow<int>();
    test_overflow<long>();
    test_overflow<long long>();

    // Unsigned integers.
    test_overflow<unsigned char>();
    test_overflow<unsigned short int>();
    test_overflow<unsigned int>();
    test_overflow<unsigned long>();
    test_overflow<unsigned long long>();

    // Real numbers.
    test_overflow<float>();
    test_overflow<double>();
    test_overflow<long double>();
}

void do_underflow_tests(const std::string& star_line)
{
    std::cout << std::endl << star_line << std::endl;
    std::cout << "*** Running Underflow Tests ***" << std::endl;
    std::cout << star_line << std::endl;

    // Testing C++ primative times see: https://www.geeksforgeeks.org/c-data-types/
    // Signed integers.
    test_underflow<char>();
    test_underflow<wchar_t>();
    test_underflow<short int>();
    test_underflow<int>();
    test_underflow<long>();
    test_underflow<long long>();

    // Unsigned integers.
    test_underflow<unsigned char>();
    test_underflow<unsigned short int>();
    test_underflow<unsigned int>();
    test_underflow<unsigned long>();
    test_underflow<unsigned long long>();

    // Real numbers.
    test_underflow<float>();
    test_underflow<double>();
    test_underflow<long double>();
}

/// <summary>
/// Entry point into the application.
/// </summary>
/// <returns>0 when complete</returns>
int main()
{
    //  Create a string of "*" to use in the console.
    const std::string star_line = std::string(50, '*');

    std::cout << "Beginning numberic overflow & underflow test." << std::endl;

    // Run the overfloww test.
    do_overflow_tests(star_line);

    // Run the underflow test.
    do_underflow_tests(star_line);

    std::cout << std::endl << "All numeric overflow & underflow tests completed." << std::endl;

    return 0;
}
